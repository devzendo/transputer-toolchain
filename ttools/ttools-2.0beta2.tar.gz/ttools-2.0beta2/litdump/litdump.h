/* $Id: litdump.h,v 1.1.1.1 1995/12/22 12:25:10 sizif Exp $ */

#include "shared.h"
#include "disassemble.h"
