/*
 --  ------------------------------------------------------------------------
 --
 --      inmos.h
 --
 --      Some global definitions
 --
 --  modified Jeremy Thorp 21/2/90
 --
 --  -------------------------------------------------------------------------
*/



#ifndef _INMOS_H
#define _INMOS_H
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif
#define BOOL short int

#define INT32 long

#ifdef SUN3
#define BIG_ENDIAN
#else
#define LITTLE_ENDIAN
#endif

#ifndef TRUE 
#define TRUE 1
#endif
#ifndef FALSE 
#define FALSE 0
#endif

#ifndef PUBLIC
#define PUBLIC
#endif
#ifndef PRIVATE
#define PRIVATE static
#endif
#define VOID void

#define LINK int


/*
 *   Eof
 */

