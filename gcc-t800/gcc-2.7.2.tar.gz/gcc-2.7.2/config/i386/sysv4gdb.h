/* Target definitions for GNU compiler for Intel 80386 running System V.4
   with gas and gdb.  */

/* Use stabs instead of DWARF debug format.  */
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG

#include "i386/sysv4.h"
